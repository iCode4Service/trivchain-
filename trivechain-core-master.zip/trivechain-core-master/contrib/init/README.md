Sample configuration files for:

SystemD: trivechaind.service
Upstart: trivechaind.conf
OpenRC:  trivechaind.openrc
         trivechaind.openrcconf
CentOS:  trivechaind.init
OS X:    org.trivechain.trivechaind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
